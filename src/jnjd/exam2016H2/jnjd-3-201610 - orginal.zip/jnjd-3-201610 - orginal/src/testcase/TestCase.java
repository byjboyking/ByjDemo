package testcase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import huawei.TaskService;
import huawei.TaskService.Operation;
import huawei.TaskService.Result;

public class TestCase {
	
	private List<Result> results = new ArrayList<Result>();
	private List<Result> expected = new ArrayList<Result>();

	@Before
	public void setUp() throws Exception {
		results.clear();
		expected.clear();
	}

	@Test
	public void testcase01() {
		//fail("Not yet implemented");
		expected.add(new Result(new StringBuilder("Iello"), false));
		//...
		
		TaskService.process("src/testcase/input01.txt", results);
		checkResult(expected, results);
		
	}
	
	@Test
	public void testcase05() {
		expected.add(new Result(new StringBuilder("Iello"), false));
		//...
		
		TaskService.process("src/testcase/input05.txt", results);
		checkResult(expected, results);
		
		checkIsTwoThreads(results.get(0).executedOperations);
		
		Assert.assertTrue(checkExecuteSequence(results.get(0).executedOperations, 2,0));
		
	}
	
	private  void checkResult(List<Result> expected,List<Result> results){
		Assert.assertEquals(expected.size(), results.size());
		for(int  i=0;i<expected.size();i++){
			Assert.assertEquals(expected.get(i).result.toString(),  results.get(i).result.toString());
			Assert.assertEquals(expected.get(i).hasException,  results.get(i).hasException);
		}
	}
	
	private void checkIsTwoThreads(List<Operation> sequence){
		Map<Long,Integer> map  =new HashMap<Long,Integer>();
		for(Operation  a: sequence){
			Integer  oldValue  = map.get(a.threadId);
			int newValue  = 1;
			
			if(oldValue !=null){
				newValue += oldValue;
			}
			map.put(a.threadId, newValue);
		}
		
		Assert.assertEquals(2, map.size());
		int[] number = new  int[]{0,0};
		int index  =0;
		for(Map.Entry<Long, Integer> entry: map.entrySet()){
			number[index++] = entry.getValue();
		}
		
		Assert.assertEquals(sequence.size(), number[0]+number[1]);
		Assert.assertTrue(Math.abs(number[0]-number[1]) <2);//�����ܵ� ƽ������
	}
	
	
	private boolean  checkExecuteSequence(List<Operation> sequence, int ... values){
		int  indexOld =-1;
		for(int value: values){
			int  indexNew = findIndexInSequence(sequence, value);
			if(indexNew<=indexOld){
				return false;
			}
			
			indexOld = indexNew;
		}
		
		return  true;
	}
	
	private int findIndexInSequence(List<Operation> sequence, int  value){
		for(int i=0;i<sequence.size();i++){
			if(sequence.get(i).index == value){
				return i;
			}
		}
		
		return -1;
	}

}

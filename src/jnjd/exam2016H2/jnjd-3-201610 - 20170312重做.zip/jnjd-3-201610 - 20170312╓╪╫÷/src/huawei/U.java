package huawei;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import huawei.TaskService.InvalidParamException;
import huawei.TaskService.Operation;
import huawei.TaskService.Result;

public class U {
	private static final boolean PRINT_INFO_FLAG = true;
	private static final boolean PRINT_KEY_INFO_FLAG = true;
	private static final boolean PRINT_ERR_FLAG = true;

	private static final boolean PRINT_FLAG = true;

	public static void info(String msg) {
		info(msg, false);
	}

	public static void print(String msg) {
		if (PRINT_FLAG)
			System.out.println(msg);
	}

	// ��ӡ��ʽ���£�
	// ���̴߳�ӡ�� 18:02:53.337 - [1,main,Alive,RUNNABLE]-msg
	// �����̴߳�ӡ�� 18:02:53.337 - msg
	public static void info(String msg, boolean isShowThreadInfo) {
		if (PRINT_INFO_FLAG)
			System.out.println(collectInfo(msg, isShowThreadInfo));
	}

	public static void keyInfo(String msg) {
		keyInfo(msg, false);
	}

	public static void keyInfo(String msg, boolean isShowThreadInfo) {
		if (PRINT_KEY_INFO_FLAG)
			System.out.println(collectInfo(msg, isShowThreadInfo) + "-[�ؼ���־]");
	}

	public static void err(String msg) {
		err(msg, false);
	}

	public static void err(String msg, boolean isShowThreadInfo) {
		if (PRINT_ERR_FLAG)
			System.err.println(collectInfo(msg, isShowThreadInfo));
	}

	public static void infoOrErr(String msg, boolean isShowThreadInfo, boolean isInfo) {
		if (isInfo)
			info(msg, isShowThreadInfo);
		else
			err(msg, isShowThreadInfo);
	}

	private static String getCurrentDatetime() {
		// ��ʽ��23:36:50.333
		SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss.SSS");
		String formatDataTime = df.format(new Date(System.currentTimeMillis()));
		return formatDataTime;
	}

	private static String collectInfo(String msg, boolean showThread) {
		String threadInfo = "";
		if (showThread) {
			threadInfo = collectionThreadInfo();
			return getCurrentDatetime() + " - " + threadInfo + "-" + msg;
		} else {
			return getCurrentDatetime() + " - " + msg;
		}
	}

	private static String collectionThreadInfo() {
		Thread t = Thread.currentThread();
		// final String id = fillBlankChars(String.valueOf(t.getId()), 2);
		final String id = String.valueOf(t.getId());

		// max: Thread-0
		// final String name = fillBlankChars(t.getName(),9);
		final String name = t.getName();

		// max: false;
		// final String isAlive = fillBlankChars(String.valueOf(t.isAlive()),
		// 5);
		final String isAlive = t.isAlive() ? "Alive" : "NOT Alive";
		// max: TIMED_WAITING
		// final String state = fillBlankChars(t.getState().toString(),10);
		final String state = t.getState().toString();

		/*
		 * return "[tid:"+id+" ;name:"+name+" ;isAlive:"+isAlive+
		 * " ;state:"+state+"]";
		 */

		return "[" + id + "," + name + "," + isAlive + "," + state + "]";
	}

	public static void readTxtToList(final String srcTxtFile, List<String> lineList) {
		lineList.clear();
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(srcTxtFile));
			String tempString = null;
			while ((tempString = reader.readLine()) != null) {
				lineList.add(tempString);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	private final static String REGEX_SPACE = "[\\s]*";
	private final static String REGEX_NUMBER = "[-]?[0-9]+"; // ������������
	private final static String REGEX_COMMA = "[\\,]{1}";
	private final static String REGEX_LEFT_BRACKET = "[\\(]{1}";
	private final static String REGEX_RIGHT_BRACKET = "[\\)]{1}";

	// ) , (
	private final static String REGEX_SPLITTER = REGEX_RIGHT_BRACKET + REGEX_SPACE + REGEX_COMMA + REGEX_SPACE
			+ REGEX_LEFT_BRACKET;

	// ( 1 , 1, 1 )
	private final static String REGEX = REGEX_LEFT_BRACKET + REGEX_SPACE + "(" + REGEX_NUMBER + ")" + REGEX_SPACE
			+ REGEX_COMMA + REGEX_SPACE + "(" + REGEX_NUMBER + ")" + REGEX_SPACE + REGEX_COMMA + REGEX_SPACE + "("
			+ REGEX_NUMBER + ")" + REGEX_SPACE + REGEX_RIGHT_BRACKET;

	// (2,3,22),(-1,5,15),(-1,4,10) -> 2
	public static int getSpliterCounter(String itemsStr,String regex) {
		// sample code
		// int counter = U.getSpliterCounter(" (2,3,22),(-1,5,15),(-1,4,10)");
		// U.err("counter:"+counter);

		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(itemsStr);

		int counter = 0;
		while (m.find()) {
			counter++;
		}

		return counter;
	}

	public static List<Operation> readOperations(String input) throws InvalidParamException {
		List<Operation> itemList = new ArrayList<Operation>();

		Pattern p = Pattern.compile(REGEX);
		Matcher m = p.matcher(input);

		int index = 0;
		while (m.find()) {
			String group = m.group();
			U.err("readOps->group:  " + group);

			try {
				int dependsOn = Integer.parseInt(m.group(1).trim());
				int position = Integer.parseInt(m.group(2).trim());
				int delta = Integer.parseInt(m.group(3).trim());

				Operation op = new Operation(index, dependsOn, position, delta);

				itemList.add(op);

				index++;
			} catch (NumberFormatException e) {
				U.err("readOps->�����쳣��ֱ�ӷ���");
				// �����쳣��ֱ�ӷ���

				throw new InvalidParamException("�����ַ������쳣");
			}
		}

		return itemList;
	}

	public static void findFamilyTree(Operation op, List<Operation> rawOpsList, List<Operation> familyList)
			throws InvalidParamException {
		if (op.getDependsOn() == -1) {
			familyList.add(op);
			return;
		}

		if (isExist(op, familyList)) {
			// ѭ������
			U.err("findFamilyTree->isExist(op,familyList)�� ѭ��������throw new InvalidParamException ");
			throw new InvalidParamException("isExist(op,familyList)�� ѭ��������");
		}

		// ����1���� �Լ��ӽ�ȥ��
		familyList.add(op);

		// ����2�����Ҹ��ڵ�
		Operation parentOp = findOpById(op.getDependsOn(), rawOpsList);
		if (parentOp == null) {
			// �Ҳ������ڵ�
			U.err("findFamilyTree->parentOp==null��throw new InvalidParamException ");
			throw new InvalidParamException("parentOp==null");
		}

		// ����3���ݹ����
		findFamilyTree(parentOp, rawOpsList, familyList);
	}

	private static Operation findOpById(int index, List<Operation> rawOpsList) {
		for (Operation item : rawOpsList) {
			if (index == item.index)
				return item;
		}

		return null;
	}

	private static boolean isExist(Operation op, List<Operation> rawOpsList) {
		for (Operation item : rawOpsList) {
			if (op.index == item.index)
				return true;
		}

		return false;
	}

	public static boolean isValidInput(String src, String validCharSet) {
		for (int i = 0; i < src.length(); i++) {
			int index = validCharSet.indexOf(src.charAt(i));
			if (index == -1) {
				return false;
			}
		}

		return true;
	}

	// rawOperations
	public static List<Operation> sortOperationList(List<Operation> rawList) {
		List<Operation> sortList = new ArrayList<Operation>();

		int maxDepth = rawList.size();
		for (int i = 1; i <= maxDepth; i++) {
			for (Operation op : rawList) {
				if (op.depth == i) {
					sortList.add(op);
				}
			}
		}

		return sortList;
	}

	private final static String charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

	public static Result read(String line) {
		int firstCommaIndex = line.indexOf(",");
		if (firstCommaIndex == -1) {
			Result result = new Result(new StringBuilder(line), true);
			U.err("δ�ҵ����ţ�hasException=true");
			return result;
		}

		String inputStr = line.substring(0, firstCommaIndex);
		inputStr = inputStr.trim();

		if (!U.isValidInput(inputStr, charset)) {
			U.err("process->inputStr ���ڷǷ��ַ���");
			Result result = new Result(new StringBuilder(inputStr), true);
			return result;
		}

		if (inputStr.isEmpty()) {
			U.err("process->inputStr Դ�ַ���Ϊ�գ�");
			Result result = new Result(new StringBuilder(inputStr), true);
			return result;
		}
		String operationsStr = line.substring(firstCommaIndex + 1);

		try {
			List<Operation> operationList = U.readOperations(operationsStr);

			int spliterCounter = U.getSpliterCounter(operationsStr,REGEX_SPLITTER);
			if (operationList.size() == 0) {
				U.err("Operation ����Ϊ0�� ");
				Result result = new Result(new StringBuilder(inputStr), true);
				return result;
			}

			if (operationList.size() != spliterCounter + 1) {
				U.err("Operation ����  !=  �и��ַ���+1 ");
				Result result = new Result(new StringBuilder(inputStr), true);
				return result;
			}
			
			//
			int leftBracketCounter = U.getSpliterCounter(operationsStr,REGEX_LEFT_BRACKET);
			int rightBracketCounter = U.getSpliterCounter(operationsStr,REGEX_RIGHT_BRACKET);
			if(leftBracketCounter!=rightBracketCounter || leftBracketCounter!=operationList.size()){
				U.err("leftBracketCounter!=rightBracketCounter || leftBracketCounter!=operationList.size() ");
				Result result = new Result(new StringBuilder(inputStr), true);
				return result;
			}
			
			
			// ��� ÿ�� op �����ֵ�Ƿ��쳣
			for (Operation operation : operationList) {

				if (operation.getDependsOn() < -1 || operation.getDependsOn() >= operationList.size()) {
					U.err("Operation ���ϣ� dependsOn �쳣��" + operation.getDependsOn());
					Result result = new Result(new StringBuilder(inputStr), true);
					return result;
				}

				// ������
				if (operation.getDependsOn() == operation.index) {
					U.err("Operation ���ϣ� dependsOn �쳣��" + operation.getDependsOn() + "  ������");
					Result result = new Result(new StringBuilder(inputStr), true);
					return result;
				}

				// λ���쳣
				if (operation.getPosition() < 0 || operation.getPosition() >= inputStr.length()) {
					U.err("Operation ���ϣ� position �쳣��" + operation.getPosition() + "  ");
					Result result = new Result(new StringBuilder(inputStr), true);
					return result;
				}
			}

			// ѭ����������ÿ��Ԫ�ص�familytree
			for (Operation op : operationList) {
				List<Operation> familyList = new ArrayList<Operation>();

				U.findFamilyTree(op, operationList, familyList);
				op.depth = familyList.size();
			}

			Result result = new Result(new StringBuilder(inputStr));
			result.rawOperations = operationList;
			result.sortOperations = U.sortOperationList(result.rawOperations);
			U.err("rawOperations:" + result.rawOperations.toString());
			U.err("sortOperations:" + result.sortOperations.toString());

			return result;
		} catch (InvalidParamException e) {
			Result result = new Result(new StringBuilder(inputStr), true);
			return result;
		}
	}

	public static void executeInTwoThread(List<Result> results) {
		for (Result result : results) {
			executeInTwoThread(result);
		}
	}

	public static void executeInTwoThread(Result result) {
		// ��ִ�е�һ���߳�
		WrapperList wrapperList = new WrapperList(result, result.sortOperations, true);
		Thread t1 = new Thread(new WorkThread("Thread1", wrapperList, true));
		Thread t2 = new Thread(new WorkThread("Thread2", wrapperList, false));
		t1.start();
		t2.start();

		try {
			// �ȴ�t1��t2ִ����ɺ��ټ���ִ�����߳�
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// e.printStackTrace();
		}

		U.info("main->end", true);
	}

	private static class WrapperList {
		public Result result;
		public List<Operation> list;
		public boolean isFirstThread = true;
		public boolean anotherThreadRunning = true;

		public WrapperList(Result result, List<Operation> list, boolean isFirstThread) {
			this.result = result;
			this.list = list;
			this.isFirstThread = isFirstThread;
		}
	}

	private static class WorkThread implements Runnable {
		private String threadName;
		private WrapperList wrapperList;
		private boolean isFirstThread = false;

		public WorkThread(String name, WrapperList wrapperList, boolean isFirstThread) {
			this.threadName = name;
			this.wrapperList = wrapperList;
			this.isFirstThread = isFirstThread;
		}

		@Override
		public void run() {
			synchronized (wrapperList) {
				while (wrapperList.list.size() > 0) {
					if (isFirstThread != wrapperList.isFirstThread && wrapperList.anotherThreadRunning) {
						try {
							wrapperList.wait();
						} catch (InterruptedException e) {
							U.info("ThreadName:" + threadName + "->run()-InterruptedException:" + e, true);
						}
					}

					if (wrapperList.list.size() == 0) {
						U.info("ThreadName:" + threadName + "->run()-wrapperList.list.size() == 0, break", true);
						break;
					}

					// process
					Operation item = wrapperList.list.remove(0);
					try {
						item.execute(wrapperList.result);
					} catch (InvalidParamException e) {
						// e.printStackTrace();
						wrapperList.result.hasException = true;
					}

					// �л�������һ���߳�ȥ������
					wrapperList.isFirstThread = !wrapperList.isFirstThread;
					U.info("ThreadName:" + threadName + "->run()->remove item:" + item, true);
					wrapperList.notifyAll();
				}

				// ���ñ��λ��ȷ�� ���� һ���߳�Ҳ�������� ��ֹ
				wrapperList.anotherThreadRunning = false;
				wrapperList.notifyAll();
			}

			U.info("ThreadName:" + threadName + "->run()-> finish", true);
		}
	}

	public static void readToResults(String filePath, List<Result> results) {
		List<String> lineList = new ArrayList<String>();
		U.readTxtToList(filePath, lineList);

		// ��ȡÿһ�У� ������Result��
		for (String line : lineList) {
			if (line.trim().isEmpty()) {
				U.err("���к���");
				continue;
			}

			Result result = U.read(line);
			results.add(result);
		}
	}
}
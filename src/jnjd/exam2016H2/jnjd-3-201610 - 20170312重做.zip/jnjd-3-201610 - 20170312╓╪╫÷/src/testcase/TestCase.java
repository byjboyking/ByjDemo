package testcase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import huawei.TaskService;
import huawei.U;
import huawei.TaskService.Operation;
import huawei.TaskService.Result;

public class TestCase {
	
	private List<Result> results = new ArrayList<Result>();
	private List<Result> expected = new ArrayList<Result>();

	@Before
	public void setUp() throws Exception {
		results.clear();
		expected.clear();
	}

	
	@Test
	public void testcase001() {
		System.out.println("-----------testcase001 �����ַ�����û�ж���------------");
		expected.add(new Result(new StringBuilder("Hello"), true));
		TaskService.process("src/testcase/input001.txt", results);
		checkResult(expected, results);
	}
	
	@Test
	public void testcase002() {
		System.out.println("-----------testcase002 ��������------------");
		expected.add(new Result(new StringBuilder("Iello"), false));
		TaskService.process("src/testcase/input002.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase003() {
		System.out.println("-----------testcase003 ���к���------------");
		expected.add(new Result(new StringBuilder("Iello"), false));
		expected.add(new Result(new StringBuilder("Iello"), false));
		
		TaskService.process("src/testcase/input003.txt", results);
		checkResult(expected, results);
	}
	
	@Test
	public void testcase004() {
		System.out.println("-----------testcase004 Դ�ַ�����ͷ�ͽ�β�Ŀո񱻺���------------");
		expected.add(new Result(new StringBuilder("Iello"), false));
		
		TaskService.process("src/testcase/input004.txt", results);
		checkResult(expected, results);
	}
	
	@Test
	public void testcase005() {
		System.out.println("-----------testcase005 Դ�ַ����зǷ��ַ���------------");
		expected.add(new Result(new StringBuilder("Hel!lo"), true));
		
		TaskService.process("src/testcase/input005.txt", results);
		checkResult(expected, results);
	}
	
	@Test
	public void testcase006() {
		System.out.println("-----------testcase006 Դ�ַ���Ϊ��------------");
		expected.add(new Result(new StringBuilder(""), true));
		
		TaskService.process("src/testcase/input006.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase007() {
		System.out.println("-----------testcase007 �����ַ������Ϸ�-operation==0  ------------");
		expected.add(new Result(new StringBuilder("Hello"), true));
		
		TaskService.process("src/testcase/input007.txt", results);
		checkResult(expected, results);
	}
	
	@Test
	public void testcase008() {
		System.out.println("-----------testcase008 �����ַ������Ϸ�-op ֮����и��ַ��쳣  ------------");
		expected.add(new Result(new StringBuilder("BestWishes"), true));
		
		TaskService.process("src/testcase/input008.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase009() {
		System.out.println("-----------testcase009 �����ַ������Ϸ�-op ֮����и��ַ��� op����������ƥ��  ------------");
		expected.add(new Result(new StringBuilder("BestWishes"), true));
		
		TaskService.process("src/testcase/input009.txt", results);
		checkResult(expected, results);
	}
	
	@Test
	public void testcase010() {
		System.out.println("-----------testcase010 �����ַ������Ϸ�-depends �쳣  ------------");
		expected.add(new Result(new StringBuilder("Hello"), true));
		
		TaskService.process("src/testcase/input010.txt", results);
		checkResult(expected, results);
	}
	
	@Test
	public void testcase011() {
		System.out.println("-----------testcase011 �����ַ������Ϸ�-depends �쳣  ------------");
		expected.add(new Result(new StringBuilder("Hello"), true));
		
		TaskService.process("src/testcase/input011.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase012() {
		System.out.println("-----------testcase012 �����ַ������Ϸ�-depends �쳣-������  ------------");
		expected.add(new Result(new StringBuilder("Hello"), true));
		
		TaskService.process("src/testcase/input012.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase013() {
		System.out.println("-----------testcase013 �����ַ������Ϸ�-position�쳣  ------------");
		expected.add(new Result(new StringBuilder("Hello"), true));
		
		TaskService.process("src/testcase/input013.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase014() {
		System.out.println("-----------testcase014 �����ַ������Ϸ�-ѭ������  ------------");
		expected.add(new Result(new StringBuilder("Hello"), true));
		
		TaskService.process("src/testcase/input014.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase015() {
		System.out.println("-----------testcase015 ���Ϊ4������ ------------");
		expected.add(new Result(new StringBuilder("Lello"), false));
		
		TaskService.process("src/testcase/input015.txt", results);
		checkResult(expected, results);
		
		checkIsTwoThreads(results.get(0).executedOperations);
	}
	
	@Test
	public void testcase016() {
		//�������û��д�������ú÷�˼����
		System.out.println("-----------testcase016 ����������13- ������Ŀ�쳣 ------------");
		expected.add(new Result(new StringBuilder("abcdEF"), true));
		expected.add(new Result(new StringBuilder("abcdEF"), true));
		expected.add(new Result(new StringBuilder("abcdEF"), true));
		
		TaskService.process("src/testcase/input016.txt", results);
		checkResult(expected, results);
	}
	
	
	@Test
	public void testcase017() {
		System.out.println("-----------testcase017 �����ִ��˳�� ------------");
		//Hello,(1,0,1),(-1,0,1),(0,0,1)
		//       0        1        2 
		expected.add(new Result(new StringBuilder("Kello"), false));
		TaskService.process("src/testcase/input017.txt", results);
		checkResult(expected, results);
		Assert.assertTrue(checkExecuteSequence(results.get(0).executedOperations, 1,0,2));
	}
	
//	@Test
//	public void testcase01() {
//		//fail("Not yet implemented");
//		expected.add(new Result(new StringBuilder("Iello"), false));
//		//...
//		
//		TaskService.process("src/testcase/input01.txt", results);
//		checkResult(expected, results);
//		
//	}
//	
//	@Test
//	public void testcase05() {
//		expected.add(new Result(new StringBuilder("Iello"), false));
//		//...
//		
//		TaskService.process("src/testcase/input05.txt", results);
//		checkResult(expected, results);
//		
//		checkIsTwoThreads(results.get(0).executedOperations);
//		
//		Assert.assertTrue(checkExecuteSequence(results.get(0).executedOperations, 2,0));
//		
//	}
	
	private  void checkResult(List<Result> expected,List<Result> results){
		Assert.assertEquals(expected.size(), results.size());
		for(int  i=0;i<expected.size();i++){
			Assert.assertEquals(expected.get(i).result.toString(),  results.get(i).result.toString());
			Assert.assertEquals(expected.get(i).hasException,  results.get(i).hasException);
		}
	}
	
	private void checkIsTwoThreads(List<Operation> sequence){
		Map<Long,Integer> map  =new HashMap<Long,Integer>();
		for(Operation  a: sequence){
			Integer  oldValue  = map.get(a.threadId);
			int newValue  = 1;
			
			if(oldValue !=null){
				newValue += oldValue;
			}
			map.put(a.threadId, newValue);
		}
		
		Assert.assertEquals(2, map.size());
		int[] number = new  int[]{0,0};
		int index  =0;
		for(Map.Entry<Long, Integer> entry: map.entrySet()){
			number[index++] = entry.getValue();
		}
		
		Assert.assertEquals(sequence.size(), number[0]+number[1]);
		Assert.assertTrue(Math.abs(number[0]-number[1]) <2);//�����ܵ� ƽ������
	}
	
	
	private boolean  checkExecuteSequence(List<Operation> sequence, int ... values){
		int  indexOld =-1;
		for(int value: values){
			int  indexNew = findIndexInSequence(sequence, value);
			if(indexNew<=indexOld){
				return false;
			}
			
			indexOld = indexNew;
		}
		
		return  true;
	}
	
	private int findIndexInSequence(List<Operation> sequence, int  value){
		for(int i=0;i<sequence.size();i++){
			if(sequence.get(i).index == value){
				return i;
			}
		}
		
		return -1;
	}

}
